function getShareUrl(hash) {
    var url = window.document.URL;
    if (url.indexOf("#") === -1 && typeof hash === "string")
        url += hash;
    return url;
}

function abrirfacebook(hash) {
    var dir = getShareUrl(hash);
    var tit = window.document.title;
    var tit2 = encodeURIComponent(tit);
    var url = 'http://www.facebook.com/sharer.php?u=' + dir + '&t=' + tit2;
    window.open(url, '_blank');
}

function abrirtwitter(hash) {
    var dir = getShareUrl(hash);
    var tit = window.document.title;
    var tit2 = encodeURIComponent(tit);
    var url = 'https://twitter.com/intent/tweet?text=' + tit2 + '&url=' + dir + '&via=ServersWeb';
    window.open(url, '_blank');
}

