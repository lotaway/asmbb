<?php
   //Envia un mail contacto
   if (isset($_POST)){
   	   if ((isset($_POST['source']) || ($_POST['source'] != '') ){
          if ($_POST['source'] == 'footercontact') {
             if ((isset($_POST['user']) || ($_POST['user'] != '') ){
                if ((isset($_POST['message']) || ($_POST['message'] != '') ){
                	//Limpia las variables
                	$usermail     = filter_var ($_POST['user'], FILTER_SANITIZE_EMAIL);
                	$messageemail = strip_tags ($_POST['message']);                 	
                	//En caso que hayan lineas de mas de 70 caracteres
                	$messageemail = wordwrap($messageemail, 70, "\r\n");      
                	//Envia el mail             
                    mail('eduardocolmenares@gmail.com', 'New Contact at Page Footer!!!', $messageemail);
                } //Para configurar que tenga un mensaje configurado	
             } //Para validar que el usuario este configurado
          }//En caso de que el origen venga del footer
   	   } //En caso de que el origen este configurado
   } //En caso de que se venga por un post
?>