var VUUKLE_CONFIG = {
    "apiKey": "95105085-fec9-467f-a26b-f84f9a3f030b",
    "host": "serverswebhosting.com",
    "articleId": 0,
    "url": "http://serverswebhosting.com",
    "emotes": {
        "enabled": true,
        "hideRecommendedArticles": true,
        "size": "20",
        "disable": [
            5,
            6
        ]
    }
};

function initVuukleEmoteRate(articleId, containerClassName) {
    var containers = document.getElementsByClassName(containerClassName);
    if (containers.length > 1)
        [].forEach.call(containers, function (container, index) {
            if (index !== containers.length - 1)
                container.parentElement.removeChild(container)
        })
    document.getElementById("vuukle-emote").style.display = "block"
    VUUKLE_CONFIG.articleId = articleId
    var d = document,
        s = d.createElement('script')
    s.src = 'https://cdn.vuukle.com/platform.js';
    (d.head || d.body).appendChild(s)
}