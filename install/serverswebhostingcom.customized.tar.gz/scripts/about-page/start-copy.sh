# copy all articles from directory 'articles' to each template skin folder.
# if this shell didn't have permission, try run command `chmod x start-copy.sh` or run it on sudo root user.
targetFiles=./articles/*.page
cp -r $targetFiles "../../templates/Light"
cp -r $targetFiles "../../templates/mobile"
cp -r $targetFiles "../../templates/Modern"
cp -r $targetFiles "../../templates/MoLight"
cp -r $targetFiles "../../templates/Urban Sunrise"
cp -r $targetFiles "../../templates/Wasp"